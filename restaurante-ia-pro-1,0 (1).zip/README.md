# 🍗 Restaurante IA Pro

Este es un sistema de punto de venta (POS) para restaurantes, mejorado con funciones de inteligencia artificial.

## 🚀 Despliegue en Netlify + Supabase

Sigue estos pasos para desplegar tu propia instancia de la aplicación:

### 1. Configurar Supabase

1.  Crea un nuevo proyecto en [Supabase](https://supabase.com/).
2.  Dentro de tu proyecto, ve a `SQL Editor` y ejecuta el siguiente script para crear las tablas necesarias:

    ```sql
    -- Tabla genérica para almacenar JSON
    CREATE TABLE generic_table (
      id TEXT PRIMARY KEY,
      data JSONB,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );

    -- Crear tablas específicas usando la estructura genérica
    CREATE TABLE users AS TABLE generic_table;
    CREATE TABLE roles AS TABLE generic_table;
    CREATE TABLE sedes AS TABLE generic_table;
    CREATE TABLE menu_items AS TABLE generic_table;
    CREATE TABLE tables AS TABLE generic_table;
    CREATE TABLE zones AS TABLE generic_table;
    CREATE TABLE inventory AS TABLE generic_table;
    CREATE TABLE orders AS TABLE generic_table;
    CREATE TABLE sales AS TABLE generic_table;
    CREATE TABLE customers AS TABLE generic_table;
    CREATE TABLE expenses AS TABLE generic_table;
    CREATE TABLE delivery_rates AS TABLE generic_table;

    -- Tabla para configuraciones
    CREATE TABLE settings (
      key TEXT PRIMARY KEY,
      value JSONB,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );

    -- Habilitar Realtime para todas las tablas
    ALTER PUBLICATION supabase_realtime ADD TABLE users, roles, sedes, menu_items, tables, zones, inventory, orders, sales, customers, expenses, delivery_rates, settings;

    -- Crear bucket de almacenamiento para recibos
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('receipts', 'receipts', true);

    -- Crear política de acceso público para el bucket
    CREATE POLICY "Public receipts" ON storage.objects
    FOR SELECT USING (bucket_id = 'receipts');

    CREATE POLICY "Allow public uploads" ON storage.objects
    FOR INSERT WITH CHECK (bucket_id = 'receipts');
    ```

3.  Ve a `Project Settings` > `API`.
4.  Copia la `Project URL` y la `public` `anon` key. Las necesitarás para Netlify.

### 2. Desplegar en Netlify

1.  Haz un fork de este repositorio en tu cuenta de GitHub.
2.  Ve a [Netlify](https://app.netlify.com/start) y crea un nuevo sitio desde Git.
3.  Selecciona tu repositorio.
4.  Configura los ajustes de build:
    *   **Build command:** `npm run build`
    *   **Publish directory:** `dist`
5.  Añade las siguientes variables de entorno en `Site settings` > `Build & deploy` > `Environment`:
    *   `VITE_SUPABASE_URL`: La URL de tu proyecto de Supabase.
    *   `VITE_SUPABASE_ANON_KEY`: La clave `anon` `public` de tu proyecto de Supabase.
    *   `API_KEY`: Tu API Key de Google Gemini (opcional, para funciones de IA).

6.  Haz clic en `Deploy site`. Netlify construirá y desplegará tu aplicación.

### 3. Primer Inicio de Sesión

Una vez desplegado, la base de datos estará vacía. La aplicación lo detectará y sembrará los datos iniciales automáticamente. Podrás iniciar sesión con las credenciales por defecto:
*   **Usuario:** `admin`
*   **Contraseña:** `123`

Se recomienda cambiar esta contraseña inmediatamente en `Configuración > Usuarios`.
